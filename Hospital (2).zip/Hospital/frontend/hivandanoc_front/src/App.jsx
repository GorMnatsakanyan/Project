import React from 'react';
import './App.css'

import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import Header from './components/Header/Header';
import Doctors from './pages/Doctors'
import Appointment from './pages/Appointment';
import DoctorsLogin from './pages/DoctorsLogin';
import DoctorsRegister from './pages/DoctorsRegistration';
import Dashboard from './pages/Dashboard';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Header />
        <Routes>
          <Route path="/" element={<Home />} /> 
          <Route path="/doctors" element={<Doctors />}/>
          <Route path="/appointment" element={<Appointment />} /> 
          <Route path="/login" element={<DoctorsLogin />} />
          <Route path="/register" element={<DoctorsRegister/>}/>
          <Route path="/dashboard" element={<Dashboard/>}/>

        </Routes>
       

      </div>
    </BrowserRouter>
  )
}

export default App
