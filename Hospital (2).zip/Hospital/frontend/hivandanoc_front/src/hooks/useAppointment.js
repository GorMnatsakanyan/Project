import {useState} from 'react'

export const useAppointment = () =>{
    const [formData,setFormData] = useState({
        name: '',
        surname: '',
        fatherName: '',
        email: '',
        phone: '',
        address: '',
        time: ''
    })

    const [errors, setErrors] = useState({})

    const handleChange = (e)=>{
        const{name, value} = e.target
        setFormData({...formData, [name]:value})
    }

    const validateForm = ()=>{
        const newErrors = {}
        let isValid = true

        if(!formData.name){
            newErrors.name = "Անունը պարտադիր է"
            isValid = false
        }
        if(!formData.surname){
            newErrors.surname = "Ազգանունը պարտադիր է"
            isValid = false
        }
        if(!formData.fatherName){
            newErrors.fatherName = "Հայրանունը պարտադիր է"
            isValid = false
        }
        if(!/\S+@\S+\.\S+/.test(formData.email)){
            newErrors.name = "Էլ․ հասցեն սխալ է"
            isValid = false
        }
        if (!/^\d{9}$/.test(formData.phone)) {
           newErrors.phone = 'Հեռախոսահամարը պետք է ունենա առնվազն 9 նիշ';
           isValid = false;
        }
        if(!formData.address){
            newErrors.address = "Հասցեն պարտադիր է"
            isValid = false
        }
        if(!formData.time){
            newErrors.time = "Այցելության ժամը պարտադիր է"
            isValid = false
        }

        setErrors(newErrors);
        return isValid
    }

    return {
       formData, errors, handleChange, validateForm, setFormData 
    }
}