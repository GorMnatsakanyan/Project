import { useState } from 'react';
import { useNavigate } from 'react-router-dom';  // Import useNavigate

export default function useLoginForm() {
  const navigate = useNavigate();  // Initialize navigate
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    // Check if email and password are empty
    if (!email || !password) {
      setError('Խնդրում եմ լրացրեք դաշտերը');  // Show error message
      return;  // Do not proceed with navigation
    }

    setError('');  // Clear any previous error

    // Navigate to dashboard if both fields are filled
    navigate("/dashboard");
  };

  return {
    email,
    setEmail,
    password,
    setPassword,
    error,
    handleSubmit,
  };
}
