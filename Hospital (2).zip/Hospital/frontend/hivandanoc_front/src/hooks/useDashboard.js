import { useState } from "react";

export default function useDashboard() {
  const [appointments, setAppointments] = useState([
    { id: 1, name: "John", surname: "Smith" },
    { id: 2, name: "Emma", surname: "Brown" },
    { id: 3, name: "David", surname: "Wilson" },
  ]);

  const deleteAppointment = (id) => {
    setAppointments(prev => prev.filter(a => a.id !== id));
  };

  return {
    appointments,
    deleteAppointment,
  };
}
