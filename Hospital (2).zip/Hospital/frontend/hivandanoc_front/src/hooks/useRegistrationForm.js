import { useState } from 'react';

const useRegistrationForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    surname: '',
    profession: '',
    email: '',
    password: '',
  });
  
  const [errors, setErrors] = useState({});

  const validate = () => {
    const errors = {};

    if (!formData.name) errors.name = 'Անունը պարտադիր է';
    if (!formData.surname) errors.surname = 'Ազգանունը պարտադիր է';
    if (!formData.profession) errors.profession = 'Մասնագիտությունը պարտադիր է';
    if (!formData.email) errors.email = 'Էլ․ հասցեն պարտադիր է';
    if (!formData.password || formData.password.length < 6) errors.password = 'Գաղտնաբառը պետք է լինի 6 նիշից';

    setErrors(errors);
    
    return Object.keys(errors).length === 0; 
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    if (validate()) {
   
      return true; 
    }
    return false; 
  };

  return { formData, errors, handleChange, handleSubmit };
};

export default useRegistrationForm;
