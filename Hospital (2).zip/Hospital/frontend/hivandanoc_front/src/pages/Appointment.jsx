import React from "react";
import Header from "../components/Header/Header";
import AppointmentForm from "../components/AppointmentForm/AppointmentForm";

const Appointment = ()=>{
    return(
        <div className="appointment-page">
            <Header/>
            <h1>Կատարեք ամրագրում</h1> 
            <AppointmentForm/>
        </div>
    )
}

export default Appointment
