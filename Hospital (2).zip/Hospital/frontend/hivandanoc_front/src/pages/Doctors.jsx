import React from "react";
import "./Doctors.css"
import Header from "../components/Header/Header";
import DoctorList from "../components/DoctorList/DoctorList";

const Doctors = () =>{
   return(
    <div>
        <Header />
        <DoctorList/>
    </div>
   ) 
}

export default Doctors