import React from "react";
import Header from "../components/Header/Header";
import RegistrationForm from "../components/RegistrationForm/RegistrationForm";

const DoctorsRegister = ()=>{
    return(
        <div className="registration-form">
          <Header/>
          <h1>Գրանցվել որպես բժիշկ</h1>
          <RegistrationForm/>
        </div>
    )
}

export default DoctorsRegister