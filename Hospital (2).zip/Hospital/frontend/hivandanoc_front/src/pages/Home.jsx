import React from 'react';
import './Home.css'
import About from "../components/About/About"
import Footer from "../components/Footer/Footer"

function Home() {
  return (
    <div className="home">
       <About/>
       <Footer/>
    </div>
  )
}

export default Home;