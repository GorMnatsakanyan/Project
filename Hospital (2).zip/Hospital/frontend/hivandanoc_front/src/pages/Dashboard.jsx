import React from "react";
import Header from "../components/Header/Header";
import DoctorsDashboard from "../components/DoctorsDashboard/DoctorsDashboard";

const Dashboard = ()=>{
    return(
        <div className="dashboard-page">
            <Header/>
            <DoctorsDashboard/>
        </div>
    )
}

export default Dashboard