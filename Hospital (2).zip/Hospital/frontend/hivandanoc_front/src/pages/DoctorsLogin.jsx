import React from "react";
import Header from "../components/Header/Header";
import LoginForm from "../components/LoginForm/LoginForm";

const DoctorsLogin = () => {
    return(
        <div className="doctors-login-page">
            <Header/>
            <h1>Մուտք որպես բժիշկ</h1>
            <LoginForm/>
        </div>
    )
}

export default DoctorsLogin