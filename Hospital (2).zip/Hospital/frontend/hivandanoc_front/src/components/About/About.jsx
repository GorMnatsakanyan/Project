// import React from "react";
// import "./About.css"

// function About(){
//    return(
//       <div className="about-wrapper">
//         <h2 className="about-title">Մեր մասին</h2>

//         <div className="about-content">
//           <div className="image-box">
//             <img src="/hospital.png" alt="About" className="about-image"/>
//           </div>
//         <div className="text-box">
//           <p>
//             Բարի գալուստ Առողջ ԲԿ, որտեղ կարեկցող խնամքը հանդիպում է առաջատար բժշկական տեխնոլոգիաներին: Առողջ ԲԿ-ում մենք հանձնառու ենք մատուցել համաշխարհային մակարդակի առողջապահական ծառայություններ ջերմ և աջակցող միջավայրում: Մեր նվիրված բժիշկների, բուժքույրերի և մասնագետների թիմը համատեղ աշխատում է անհատականացված խնամք մատուցելու համար՝ ապահովելով, որ յուրաքանչյուր հիվանդ ստանա ամենաբարձր մակարդակի ուշադրություն և բուժում: 
//           </p>
//         </div>
//       </div>
//      </div>  
//    )
// }

// export default About

import React from "react";
import "./About.css";

function About() {
  return (
    <section className="about-section">
      <div className="about-wrapper">
        <h2 className="about-title">Մեր մասին</h2>

        <div className="about-content">
          <div className="image-box">
            <img src="/hospital.png" alt="About" className="about-image"/>
          </div>

          <div className="text-box">
            <p>
             Բարի գալուստ Առողջ ԲԿ, որտեղ կարեկցող խնամքը հանդիպում է առաջատար բժշկական տեխնոլոգիաներին: Առողջ ԲԿ-ում մենք հանձնառու ենք մատուցել համաշխարհային մակարդակի առողջապահական ծառայություններ ջերմ և աջակցող միջավայրում: Մեր նվիրված բժիշկների, բուժքույրերի և մասնագետների թիմը համատեղ աշխատում է անհատականացված խնամք մատուցելու համար՝ ապահովելով, որ յուրաքանչյուր հիվանդ ստանա ամենաբարձր մակարդակի ուշադրություն և բուժում: 
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;
