import React from "react";
import useRegistrationForm from "../../hooks/useRegistrationForm";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "./RegistrationForm.css";  

const RegistrationForm = () => {
  const { formData, errors, handleChange, handleSubmit } = useRegistrationForm();
  
  const navigate = useNavigate(); // Initialize navigate

  const handleFormSubmit = (e) => {
    e.preventDefault(); // Prevent default form submit behavior

    // Perform custom validation and form submission handling
    if (handleSubmit()) { // If handleSubmit returns true or successfully executes
      navigate("/login");  // Navigate to the login page after successful registration
    }
  };

  return (
    <div className="doctors-login-page">
      <h1>Գրանցվեք որպես բժիշկ</h1>

      <form onSubmit={handleFormSubmit} className="registration-form">

        <div className="form-group">
          <label>Անուն:</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
          />
          {errors.name && <p className="error-message">{errors.name}</p>}
        </div>

        <div className="form-group">
          <label>Ազգանուն:</label>
          <input
            type="text"
            name="surname"
            value={formData.surname}
            onChange={handleChange}
          />
          {errors.surname && <p className="error-message">{errors.surname}</p>}
        </div>

        <div className="form-group">
          <label>Մասնագիտություն:</label>
          <input
            type="text"
            name="profession"
            value={formData.profession}
            onChange={handleChange}
          />
          {errors.profession && <p className="error-message">{errors.profession}</p>}
        </div>

        <div className="form-group">
          <label>Էլ․ հասցե:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
          {errors.email && <p className="error-message">{errors.email}</p>}
        </div>

        <div className="form-group">
          <label>Գաղտնաբառ:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />
          {errors.password && <p className="error-message">{errors.password}</p>}
        </div>

        <button type="submit" className="register-button">
          Հաստատել
        </button>

      </form>
    </div>
  );
};

export default RegistrationForm;
