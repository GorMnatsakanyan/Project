import React from "react";
import "./DoctorsDashboard.css";
import useDashboard from "../../hooks/useDashboard";


const DoctorsDashboard = ()=> {
  const { appointments, deleteAppointment } = useDashboard();

  return (
    <div className="dashboard-container">
      <h2>Բժշկի պատուհան</h2>

      <table className="appointment-table">
        <thead>
          <tr>
            <th>Անուն</th>
            <th>Ազգանուն</th>
          </tr>
        </thead>
        <tbody>
          {appointments.map(a => (
            <tr key={a.id}>
              <td>{a.name}</td>
              <td>{a.surname}</td>
              <td>
                <button
                  className="delete-btn"
                  onClick={() => deleteAppointment(a.id)}
                >
                  Ջնջել
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DoctorsDashboard;
