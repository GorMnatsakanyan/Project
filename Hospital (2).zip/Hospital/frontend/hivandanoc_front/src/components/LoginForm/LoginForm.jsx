import React from "react";
import useLoginForm from "../../hooks/useLoginForm";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import './LoginForm.css'

const LoginForm = () => {
  const {
    email,
    setEmail,
    password,
    setPassword,
    error,
    handleSubmit,
  } = useLoginForm();
  
  const navigate = useNavigate(); // Initialize navigate

  const handleRegisterClick = () => {
    navigate("/register"); // Navigate to the registration page
  };

  return (
    <form onSubmit={handleSubmit} className="login-form">

      <div className="form-group">
        <label htmlFor="email">Էլ․ հասցե</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Մուտքագրեք ձեր էլ․ հասցեն"
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="password">Գաղտնաբառ</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Մուտքագրեք ձեր գաղտնաբառը"
          required
        />
      </div>

      {error && <p className="error-message">{error}</p>}

      <button type="submit" className="submit-button">
        Մուտք
      </button>

      <button 
        type="button" 
        className="register-button" 
        onClick={handleRegisterClick}
      >
        Գրանցվել
      </button>

    </form>
  );
};

export default LoginForm;
