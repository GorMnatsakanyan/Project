import React from "react"
import { useAppointment } from "../../hooks/useAppointment"
import "./Appointment.css"

const AppointmentForm = () => {
  const { formData, errors, handleChange, validateForm, setFormData } = useAppointment()

  const handleSubmit = (e) => {
    e.preventDefault()

    if (validateForm()) {
      console.log("Ամրագրումն կատարված է:", formData)


      setFormData({
        name: '',
        surname: '',
        fatherName: '',
        email: '',
        phone: '',
        address: '',
        time: ''
      })
    }
  }

  return (
    <div className="appointment-form-container">
      <h2>Այցի ամրագրում</h2>
      <form className="appointment-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Անուն:</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="form-input"
          />
          {errors.name && <span className="error">{errors.name}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="surname">Ազգանուն:</label>
          <input
            type="text"
            id="surname"
            name="surname"
            value={formData.surname}
            onChange={handleChange}
            className="form-input"
          />
          {errors.surname && <span className="error">{errors.surname}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="fatherName">Հայրանուն:</label>
          <input
            type="text"
            id="fatherName"
            name="fatherName"
            value={formData.fatherName}
            onChange={handleChange}
            className="form-input"
          />
          {errors.fatherName && <span className="error">{errors.fatherName}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="email">Էլ․ հասցե:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="form-input"
          />
          {errors.email && <span className="error">{errors.email}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="phone">Հեռ․ համար:</label>
          <input
            type="text"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            className="form-input"
          />
          {errors.phone && <span className="error">{errors.phone}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="address">Հասցե:</label>
          <textarea
            id="address"
            name="address"
            value={formData.address}
            onChange={handleChange}
            className="form-input"
          />
          {errors.address && <span className="error">{errors.address}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="time">Ժամ:</label>
          <input
            type="time"
            id="time"
            name="time"
            value={formData.time}
            onChange={handleChange}
            className="form-input"
          />
          {errors.time && <span className="error">{errors.time}</span>}
        </div>

        <button type="submit" className="submit-btn">Ամրագրել</button>
      </form>
    </div>
  )
}

export default AppointmentForm
