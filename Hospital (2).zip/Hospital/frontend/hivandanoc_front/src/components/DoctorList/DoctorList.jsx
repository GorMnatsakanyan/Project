import React from "react";
import "./DoctorsList.css";
import { useNavigate} from "react-router-dom";

const doctors = [
  { name: "Տիգրան Տիգրանյան", profession: "Վիրաբույժ" },
  { name: "Դավիթ Առաքելյան", profession: "Մանկաբույժ" },
  { name: "Արման Սիմոնյան", profession: "Ակնաբույժ" },
  { name: "Գոռ Մնացականյան", profession: "Նյարդաբան" },
  { name: "Գայանե Գևորգյան", profession: "Նյարդաբան" }
];

export default function DoctorList() {
  const navigate = useNavigate()
  const handleRegisterClick = ()=>{
    navigate('/appointment')
  }

  return (
    <div className="doctors-container">
      <div className="top-header">Բժիշկների ցուցակ</div>

      {doctors.map((doc, i) => (
        <div className="doctor-row" key={i}>
          <span>{doc.name} - {doc.profession}</span>
          <button onClick={handleRegisterClick}>Գրանցվել ընդունելության</button>
        </div>
      ))}
    </div>
  );
}

