import React from "react";
import "./Footer.css"

function Footer(){
    return(
      <footer className="footer">
        <div className="footer-content">
            <div className="footer-section">
               <h3>Առողջ ԲԿ</h3>
               <p>Մենք ապահովում ենք որակյալ բուժսպասարկում և հոգատար վերաբերմունք։</p>
            </div>

            <div className="footer-section">
                <h4>Կապ մեզ հետ</h4>
                <p>📞 +374 91 19 19</p>
                <p>📧 info@aroxjbk.am</p>
                <p>📍 Երևան, Հայաստան</p>
            </div>

        </div>

        <div className="footer-bottom">
            © {new Date().getFullYear()} Առողջ ԲԿ — Բոլոր իրավունքները պաշտպանված են։
        </div>
      </footer>  
    )
}

export default Footer