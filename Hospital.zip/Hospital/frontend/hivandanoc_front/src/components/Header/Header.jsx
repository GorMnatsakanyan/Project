import React from "react";
import { Link } from 'react-router-dom';
import './Header.css'


function Header(){
    return(
        <header className="header">
           <div className="logo-container">
           <Link to="/">
              <img src="/logo.png" alt="App logo" className="logo"/>
           </Link>
           </div>

           <nav>
             <Link to="/">Գլխավոր</Link>
             <Link to="/">Բժիշկների ցանկ</Link>
             <Link to="/">Բժշկի համար</Link>
           </nav>
        </header>
    )
}

export default Header;