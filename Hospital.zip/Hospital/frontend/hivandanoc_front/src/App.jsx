// import { useState } from 'react'
import React from 'react';
import './App.css'

import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import Header from './components/Header/Header';
import About from './components/About/About';
import Footer from './components/Footer/Footer';

function App() {


  return (
    <BrowserRouter>
      <div className="App">
        <Header />
        <About/>
        <Footer/>
        <Routes>
          <Route path="/" element={<Home />} /> 
        </Routes>
      </div>
    </BrowserRouter>
  )
}

export default App
